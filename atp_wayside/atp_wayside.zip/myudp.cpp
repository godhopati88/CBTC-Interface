#include "myudp.h"

void MyUdp::runServer(QString ipAddress, quint16 ipPort)
{
    socket = new QUdpSocket(this);
    QHostAddress ip(ipAddress);
    socket->bind(ip,ipPort);

    qDebug() << "UDP as Server, bind:" << ip << ipPort;

    connect(socket,SIGNAL(readyRead()),this,SLOT(SERVER_readyRead()));

    // Auto send every 200 seconds
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(CHECK_timeout()));
    timer->start(200);
}

void MyUdp::runClient(QString ipAddress, quint16 ipPort, QString Hostname)
{
    hostname=Hostname;
    port = ipPort;
    tick=0;
    rxFlag=false;
    count_timeout=0;

    socket = new QUdpSocket(this);
    QHostAddress ip(ipAddress);
    socket->bind(ip,ipPort);

    qDebug() << "UDP as Client, bind:" << ip << ipPort;

    connect(socket,SIGNAL(readyRead()),this,SLOT(CLIENT_readyRead()));

    // Auto send every 200 seconds
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(CLIENT_autoSend()));
    timer->start(200);
}

void MyUdp::CLIENT_readyRead()
{
    QByteArray buffer;
    QHostAddress sender;
    quint16 senderPort;

    buffer.resize(socket->pendingDatagramSize());

    socket->readDatagram(buffer.data(),buffer.size(),
                         &sender,&senderPort);
    qDebug() << "udpClient _message from: " << sender.toString() <<senderPort;

    if (checkCRC16Kermit(buffer)==true && sender.toString()==hostname)
    {
        rxData=buffer;
        qDebug() << "udpClient _rx data: " << rxData;

        status = "Connected !";
        rxFlag=true;
        count_timeout=0;
    }
    else
    {
        qDebug() << "udpClient _rx data <not valid !> : " << buffer;
    }

}

void MyUdp::SERVER_readyRead()
{
    QByteArray buffer;
    buffer.resize(socket->pendingDatagramSize());

    QHostAddress sender;
    quint16 senderPort;

    socket->readDatagram(buffer.data(),buffer.size(),
                         &sender,&senderPort);
    qDebug() << "udpServer _message from: " << sender.toString() << "port: " <<senderPort;
    qDebug() << "udpServer _message: " << buffer;

    if (checkCRC16Kermit(buffer)==true)
    {
        rxData=buffer;
        qDebug() << "udpServer _rx data: " << rxData;

        status = "Connected !";
        rxFlag=true;
        count_timeout=0;
    }
    else
    {
        qDebug() << "udpServer _rx data <not valid !> : " << buffer;
    }

    txData.append(getCRC16Kermit(txData));
    socket->writeDatagram(txData,sender,senderPort);

    qDebug() << "udpServer _tx data : " << txData;
}

void MyUdp::CLIENT_autoSend()
{
    QByteArray buffer;
    QHostAddress ipHost(hostname);

    buffer.append(QByteArray::number(tick));
    buffer.append(txData);
    buffer.append(getCRC16Kermit(buffer));
    socket->writeDatagram(buffer,ipHost,port);
    qDebug() << "udpClient _tx data : " << buffer;

    buffer.clear();

    tick ^= 1 << 0;  // Generate tick

    if(!rxFlag)count_timeout++;
    if(count_timeout >= 5) {
        count_timeout=5;
        qDebug() << "udpClient _Timeout for hostname: " <<  hostname << port;
        status = "Timeout";
        rxData="";
    }
    rxFlag=false;
}

void MyUdp::CHECK_timeout()
{
    if(!rxFlag)count_timeout++;
    if(count_timeout >= 5) {
        count_timeout=5;
        qDebug() << "udpServer _Timeout getting data..";
        status = "Timeout";
        rxData="";
    }
    rxFlag=false;
}

QByteArray MyUdp::getCRC16Kermit(const QByteArray &data)
{
    quint16     valuehex = 0;
    quint16     CRC = 0;
    int         size = data.size();
    CRC = 0;
    QByteArray result;

    for(int i=0; i<size; ++i) {
        valuehex = ((static_cast<quint8>(data[i]) ^ CRC) & 0x0fu) * 0x1081;
        CRC >>= 4;
        CRC ^= valuehex;
        valuehex = ((static_cast<quint8>(data[i]) >> 4) ^ (CRC & 0x00ffu)) & 0x0fu;
        CRC >>= 4;
        CRC ^= (valuehex * 0x1081u);
    }
    quint16 ret = ( (CRC & 0x00ffu) << 8) | ((CRC & 0xff00u) >> 8);

    //return QByteArray::number(ret,16);
    return result.append(QString("%1").arg(ret, 4, 16, QLatin1Char( '0' )));
}

bool MyUdp::checkCRC16Kermit(QByteArray dataPacket)
{
    /* Parsing Data */
    quint16 startBit = dataPacket.size() - 4;
    quint16 hashBit = dataPacket.size() - startBit;
    QByteArray data = dataPacket.left(startBit);
    QByteArray hashData = dataPacket.right(hashBit);

    /* Checksum CRC16Kermit */
    if(getCRC16Kermit(data)==hashData)return true;
    else return false;
}

QByteArray MyUdp::getOriginalData(QByteArray dataPacket)
{
    /* Parsing Data */
    quint16 startBit = dataPacket.size() - 4;
    return dataPacket.mid(1,startBit-1);
}

