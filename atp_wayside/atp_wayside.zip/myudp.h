#ifndef MYUDP_H
#define MYUDP_H

#include <QObject>
#include <QTimer>
#include <QtNetwork>
#include <QUdpSocket>

class MyUdp : public QObject
{
    Q_OBJECT
public:
    void runServer(QString ipAddress, quint16 ipPort);
    void runClient(QString ipAddress, quint16 ipPort, QString Hostname);
    QByteArray txData, rxData, status;

private:
    QByteArray getCRC16Kermit(const QByteArray &data);
    bool checkCRC16Kermit(QByteArray dataPacket);
    QByteArray getOriginalData(QByteArray dataPacket);

    QUdpSocket *socket;
    QString hostname;
    quint16 port;
    quint8 tick;

    quint16 count_timeout;
    bool rxFlag;

private slots:
    void CLIENT_readyRead();
    void SERVER_readyRead();
    void CLIENT_autoSend();
    void CHECK_timeout();
};

#endif // MYUDP_H
